<template>
    <h3 class="font-bold text-[20px] my-appSmallSize">{{ title }}</h3>
</template>

<script setup>
defineProps(["title"]);
</script>
